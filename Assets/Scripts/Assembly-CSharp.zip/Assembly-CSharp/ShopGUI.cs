public class ShopGUI : GUIMode
{
}
