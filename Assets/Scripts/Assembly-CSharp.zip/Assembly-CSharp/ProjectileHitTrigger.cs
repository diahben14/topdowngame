public class ProjectileHitTrigger : HitTrigger
{
}
